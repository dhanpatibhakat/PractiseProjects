package cat.rat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cat.rat.entity.MeetingHall;

@Repository
public interface MeetingHallRepository extends JpaRepository<MeetingHall, Integer> {

}
