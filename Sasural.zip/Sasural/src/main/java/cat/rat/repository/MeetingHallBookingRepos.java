package cat.rat.repository;

import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import cat.rat.entity.MeetingHallBooking;
import cat.rat.entity.Table;

@Repository
public interface MeetingHallBookingRepos extends JpaRepository<MeetingHallBooking, Integer> {

	@Query(value = "select * from meeting_hall_booking where date_of_booking = ?1 and meetinghall_id = ?2", nativeQuery = true)
	List<MeetingHallBooking> getByDateOfBooking(LocalDate rDate, Integer mId);

//	@Query(value = "SELECT  meetinghall_id,SUM(CASE WHEN slot_id = 1 THEN emp_id END) AS '1',"
//			+ "    SUM(CASE WHEN slot_id = 2 THEN emp_id END) AS '2',"
//			+ "    SUM(CASE WHEN slot_id = 3 THEN emp_id END) AS '3',"
//			+ "    SUM(CASE WHEN slot_id = 4 THEN emp_id END) AS '4',"
//			+ "    SUM(CASE WHEN slot_id = 5 THEN emp_id END) AS '5',"
//			+ "    SUM(CASE WHEN slot_id = 6 THEN emp_id END) AS '6',"
//			+ "    SUM(CASE WHEN slot_id = 7 THEN emp_id END) AS '7',"
//			+ "    SUM(CASE WHEN slot_id = 8 THEN emp_id END) AS '8' " + "FROM meeting_hall_booking"
//			+ "    where meetinghall_id =?2 and date_of_booking =?1" + "    GROUP BY"
//			+ "    meetinghall_id", nativeQuery = true)
//	List<Object[]> getByDateOfBooking(LocalDate rDate, Integer mId);

	@Query(value = "select * from meeting_hall_booking where date_of_booking = ?1", nativeQuery = true)
	List<MeetingHallBooking> getByDateOfBooking(LocalDate dp);

	// void gettingByMid(Integer mId);

}
