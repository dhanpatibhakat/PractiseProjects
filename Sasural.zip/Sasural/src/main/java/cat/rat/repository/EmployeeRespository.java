package cat.rat.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import cat.rat.entity.EmployeeMaster;

@Repository
public interface EmployeeRespository extends JpaRepository<EmployeeMaster, Integer> {
	EmployeeMaster findByEmpUserID(String empUserID);

	EmployeeMaster findByEmpId(Integer empId);

}
