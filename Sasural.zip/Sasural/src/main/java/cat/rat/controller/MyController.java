package cat.rat.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cat.rat.entity.EmployeeMaster;
import cat.rat.entity.MeetingHall;
import cat.rat.entity.MeetingHallBooking;
import cat.rat.entity.SlotMaster;
import cat.rat.entity.Table;
import cat.rat.repository.EmployeeRespository;
import cat.rat.repository.MeetingHallBookingRepos;
import cat.rat.repository.MeetingHallRepository;
import cat.rat.repository.SlotMasterRepository;

@Controller
public class MyController {

	@Autowired
	private EmployeeRespository employeeRespository;

	@Autowired
	private SlotMasterRepository slotMasterRepository;

	@Autowired
	private MeetingHallBookingRepos meetingHallBookingRepos;

	@Autowired
	private MeetingHallRepository meetingHallRepository;

	@RequestMapping("/")
	public String getForm() {
		return "home";

	}

	@PostMapping("/display")
	public void displayTable(@RequestParam("dp") @DateTimeFormat(pattern = "MM/dd/yyyy") LocalDate dp,
			HttpServletResponse response) throws IOException {
		System.out.println(dp);
		// List<MeetingHallBooking> meetingByDate =
		// meetingHallBookingRepos.getByDateOfBooking(dp);
		// System.out.println(meetingByDate);
		List<SlotMaster> slotList = slotMasterRepository.findAll();
		List<MeetingHall> allHall = meetingHallRepository.findAll();
		String t = "";
		String d = "";
		List<MeetingHallBooking> forAllMeetingHall = meetingHallBookingRepos.getByDateOfBooking(dp);
	//	for (MeetingHallBooking obj : forAllMeetingHall) {
			//System.out.print(obj.length + " kjkjkjkj");

			

//			for (Object ob : obj) {
//				System.out.print(ob + " ");
//
//				if (ob != null) {
//					t = t + "<td>" + employeeRespository.findById(Integer.parseInt(ob + "")).get().getEmpName()
//							+ "</td>";
//				}
//				if (ob == null)
//					t = t + "<td>" + "VACANT" + "</td>";
//			}
		
		for (MeetingHall h : allHall) {
			List<MeetingHallBooking> meetingByDate = meetingHallBookingRepos.getByDateOfBooking(dp,h.getMeetinghallId());
			t = "<tr><td class='font-weight-bold'>" + h.getMeetinghallName() + " </td>";
			for (SlotMaster s : slotList) {
				List<MeetingHallBooking> filterByDate = meetingByDate.stream()
						.filter(z -> z.getSlotID().getSlotId() == s.getSlotId()).collect(Collectors.toList());
				if (filterByDate.size() == 1) {
					// System.out.println(collect.get(0));
					t = t + "<td>" + filterByDate.get(0).getEmpId().getEmpName() + "</td>";
				} else {
					// System.out.println("Here is the slot Id Vacant - >>" + s.getSlotId());
					t = t + "<td>" + " " + "</td>";
					// <option value="${s.slotId}">${s.slotName}</option>
				}
			}
			t += "</tr>";
			d += t;
		}

		response.getWriter().write(d);
	}

	@PostMapping("/forTable")
	@ResponseBody
	public List<String> forTable(@RequestParam("rDate") @DateTimeFormat(pattern = "MM/dd/yyyy") LocalDate rDate,
			@RequestParam("mId") Integer mId, HttpServletResponse response) throws IOException {
//		System.out.println("Here is the data" + mId + "and here is the date " + rDate);
//		List<Object[]> byDateOfBooking = meetingHallBookingRepos.getByDateOfBooking(rDate, mId);
//		System.out.println("here is the required data - = = =  " + byDateOfBooking);
//		String t = "<tr><td>Booked By</td>";
//		String d = "";
//		for (Object[] obj : byDateOfBooking) {
//			System.out.print(obj.length + " kjkjkjkj");
//
//			for (int x = 1; x < obj.length; x++) {
//
//				if (obj[x] != null) {
//					t = t + "<td>" + employeeRespository.findById(Integer.parseInt(obj[x] + "")).get().getEmpName()
//							+ "</td>";
//				}
//				if (obj[x] == null) {
//					t = t + "<td>" + "VACANT" + "</td>";
//					d = d + "<option value=" + x + ">" + " Slot-" + x + "</option>";
//
//				}
//			}
//
////			for (Object ob : obj) {
////				System.out.print(ob + " ");
////
////				if (ob != null) {
////					t = t + "<td>" + employeeRespository.findById(Integer.parseInt(ob + "")).get().getEmpName()
////							+ "</td>";
////				}
////				if (ob == null)
////					t = t + "<td>" + "VACANT" + "</td>";
////			}
		//}
		//t += "</tr>";
//		List<String> toReturn = new ArrayList<String>();
//		toReturn.add(t);
//		toReturn.add(d);
//		return toReturn;
		// response.getWriter().write(t);
		// return null;
		List<SlotMaster> slotList = slotMasterRepository.findAll();
		List<MeetingHallBooking> byDateOfBooking = meetingHallBookingRepos.getByDateOfBooking(rDate, mId);
		String t = "<tr><td>Booked By</td>";
		String d = "";
		for (SlotMaster s : slotList) {
			List<MeetingHallBooking> collect = byDateOfBooking.stream()
					.filter(z -> z.getSlotID().getSlotId() == s.getSlotId()).collect(Collectors.toList());
			if (collect.size() == 1) {
				t = t + "<td>" + collect.get(0).getEmpId().getEmpName() + "</td>";
			} else {
				t = t + "<td>" + "Vacant" + "</td>";
				d = d + "<option value=" + s.getSlotId() + ">" + s.getSlotName() + "</option>";
			}

		}
		t += "</tr>";
		List<String> toReturn = new ArrayList<String>();
		toReturn.add(t);
		toReturn.add(d);
		return toReturn;
	}

	@PostMapping("/check")
	public String checkCred(@RequestParam("empUserID") String username, @RequestParam("password") String password,
			HttpServletRequest request) {
		EmployeeMaster user = employeeRespository.findByEmpUserID(username);
		if (user.getEmpPassword().equals(password)) {
			HttpSession session = request.getSession();
			session.setAttribute("user", user);
			// System.out.println(session.getAttribute("user"));
			return "dashboard";
		}

		else {
			return "forward:/";
		}

	}

//	@PostMapping("/check")
//	public String checkCred(@Valid @ModelAttribute EmployeeMaster em, BindingResult result,
//			HttpServletRequest request) {
//		System.out.println("Employee is here - - - - - " + em + "-----------------" + result);
//		// EmployeeMaster user = employeeRespository.findByEmpUserID(username);
////		if (user.getEmpPassword().equals(password)) {
////			HttpSession session = request.getSession();
////			session.setAttribute("user", user);
////			// System.out.println(session.getAttribute("user"));
////			return "dashboard";
////		}
////
////		else {
////			return "forward:/";
////		}
//
//		return null;
//	}

	@GetMapping("/scheduleMeeting")
	public String scheduleMeeting(Model model) {
		List<MeetingHall> allHalls = meetingHallRepository.findAll();
		// List<SlotMaster> allSlots = slotMasterRepository.findAll();
		model.addAttribute("halls", allHalls);
		// model.addAttribute("allSlots", allSlots);

		return "scheduler";
	}

	@PostMapping("/saved")
	public String saveMeetng(@RequestParam("meetinghall") MeetingHall meetinghall,
			@RequestParam("dp") @DateTimeFormat(pattern = "MM/dd/yyyy") LocalDate dp,
			@RequestParam("slot") SlotMaster slot, HttpServletRequest request) {
		HttpSession session = request.getSession();
		EmployeeMaster data = (EmployeeMaster) session.getAttribute("user");
		System.out.println(data);
		MeetingHallBooking m = new MeetingHallBooking();
		m.setMeetinghallId(meetinghall);
		m.setSlotID(slot);
		m.setDateOfBooking(dp);
		m.setEmpId(employeeRespository.findByEmpId(data.getEmpId()));
		meetingHallBookingRepos.save(m);
		System.out.println(meetinghall + " - - " + dp + " - - - " + slot);
		return "redirect:./scheduleMeeting";
	}

	@GetMapping("/viewMeeting")
	public String viewMeetingPage(Model model) {
		return "meetingscheduler";
	}

}
