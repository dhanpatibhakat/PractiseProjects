package cat.rat.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import lombok.Data;

@Entity
@Data
@Table(name = "Employee_Master")
public class EmployeeMaster {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "empId")
	private Integer empId;
	private String empName;
	@NotBlank(message = "ID should not be empty")
	@Size(min = 5, max = 8, message = "ID must be between 5-8 characters")
	private String empUserID;
	@NotBlank(message = "Password should not be empty")
	@Size(min = 5, max = 8, message = "ID must be between 5-8 characters")
	private String empPassword;
	private String empPhoto;
}
