package cat.rat.entity;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name = "Meeting_Hall_Booking")
public class MeetingHallBooking {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "slNo")
	private Integer slNo;
	private LocalDate DateOfBooking;
	@JoinColumn(name = "meetinghallId")
	@ManyToOne
	private MeetingHall meetinghallId;
	@ManyToOne
	@JoinColumn(name = "slotId")
	private SlotMaster SlotID;
	@ManyToOne
	@JoinColumn(name = "empId")
	private EmployeeMaster empId;
}
