package cat.rat.entity;

import lombok.Data;

@Data
public class Table {
	private Integer mId;
	private Integer sId1;
	private Integer sId2;
	private SlotMaster sId3;
	private SlotMaster sId4;
	private SlotMaster sId5;
	private SlotMaster sId6;
	private SlotMaster sId7;
	private SlotMaster sId8;
}
